#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <windows.h>
#define N 10

typedef struct link_node
{
    struct link_node *next;
    int data;
}node,*pnode,**ppnode;


void print_queue(pnode ph)
{
    while(ph)
    {
        printf("%d ",ph->data);
        ph=ph->next;
    }
    printf("\n");
}


void en_queue(ppnode ph,ppnode pt)
{
    pnode s=(pnode)calloc(1,sizeof(node));
    printf("\n���������Ԫ��:");
    scanf("%d",&s->data);
    if(*ph==NULL)
    {
        *ph=s;
        *pt=s;
    }
    else
    {
        (*pt)->next=s;
        *pt=s;
    }
}


void de_queue(ppnode ph)
{
    pnode s;
    if(*ph==NULL)
    {
        printf("����Ϊ��,�޷�����!\n");
    }
    else
    {
        s=*ph;
        printf("%d�ѳ���\n",(*ph)->data);
        *ph=(*ph)->next;
        free(s);
    }
    system("pause");
}


int main()
{
    pnode pnew,ph=NULL,pt=NULL;
    int If;
    for(;;)
    {
    print_queue(ph);
    printf("���1  ����2\n");
    scanf("%d",&If);
    if(If==1) en_queue(&ph,&pt);
    if(If==2) de_queue(&ph);
    system("cls");
    }
}
