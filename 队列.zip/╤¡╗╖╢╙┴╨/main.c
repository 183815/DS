#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <windows.h>
#define N 10

typedef struct SeQueue
{
    int a[N];
    int Front,Rear;
}sq,*psq;


void Print_seq(sq s)
{
    int i=s.Front;
    while(s.a[i])
    {
    printf("%d ",s.a[i]);
    i=(i+1)%N;
    }
    printf("\n");
}



void en_seq(psq s)
{
    int i;
    printf("���������Ԫ��:");
    scanf("%d",&i);
    (*s).a[(*s).Rear]=i;
    (*s).Rear=((*s).Rear+1)%N;
}

void de_seq(psq s)
{
    int i;
    i=(*s).a[(*s).Front];
    (*s).a[(*s).Front]=0;
    (*s).Front=((*s).Front+1)%N;
    printf("\n%d�ѳ���\n",i);
    system("pause");
}


void IF_Empty_seq(sq s)
{
    if(s.Front==s.Rear) printf("�ӿ�,��ʱ�޷�����\n");
    else if((s.Rear+1)%N==s.Front) printf("����,��ʱ�޷����!\n");
    else printf("��δ��\n");
}


int main()
{
    sq s;
    memset(s.a,0,sizeof(s.a));
    s.Front=0;s.Rear=0;
    int If;
    for(;;)
    {
        Print_seq(s);
        IF_Empty_seq(s);
        printf("��Ӱ�1  ���Ӱ�2\n");
        scanf("%d",&If);
        if(If==1&&(s.Rear+1)%N!=s.Front) en_seq(&s);
        else if(If==2&&s.Front!=s.Rear) de_seq(&s);
        system("cls");
    }
}
