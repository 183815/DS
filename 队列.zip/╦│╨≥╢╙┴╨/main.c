#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <windows.h>
#define N 10

typedef struct SeQueue
{
    int a[N];
    int Front,Rear;
}sq,*psq;


void Print_seq(sq s)
{
    int i=s.Front;
    while(s.a[i])
    {
    printf("%d ",s.a[i++]);
    }
    printf("\n");
}



void en_seq(psq s)
{
    int i;
    printf("���������Ԫ��:");
    scanf("%d",&i);
    (*s).a[(*s).Rear++]=i;
}

void de_seq(psq s)
{
    int i;
    i=(*s).a[(*s).Front];
    (*s).a[(*s).Front++]=0;
    printf("\n%d�ѳ���",i);
    system("pause");
}


void emp_seq(sq s)
{
    if(s.Front==s.Rear) printf("�ӿ�,��ʱ�޷�����\n");
    else if(s.Rear==N) printf("����,��ʱ�޷����!\n");
    else printf("��δ��\n");
}


int main()
{
    sq s;
    memset(s.a,0,sizeof(s.a));
    s.Front=0;s.Rear=0;
    int If;
    for(;;)
    {
        Print_seq(s);
        emp_seq(s);
        printf("��Ӱ�1  ���Ӱ�2\n");
        scanf("%d",&If);
        if(If==1&&s.Rear!=N) en_seq(&s);
        else if(If==2&&s.a[s.Front]!=0) de_seq(&s);
        system("cls");
    }
}
