#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <windows.h>
#define N 10

typedef struct tree
{
    int *data;
    int num;
}Tree,*TTree;


void Print_Tree(Tree t)
{   int i=0;
    long n,m=0,j=0;
    while(t.data[i]){
    n=pow(2,m++);
    for(j=0;j<n;j++)
    {
    if(i<t.num) printf("%d ",t.data[i++]);
    }
    printf("\n");
    }
    system("pause");
    system("cls");
}


void Destroy_Tree(TTree t)
{
    free(t);
}


void Creat_Tree(TTree t)
{
    int i;
    printf("����������Ľ�����:");
    scanf("%d",&(*t).num);
    (*t).data=(int)calloc(1,sizeof(int)*(*t).num);
    printf("��������ڵ�:");
    scanf("%d",&(*t).data[0]);
    for(i=1;i<(*t).num;i++)
    {   if(i%2==0) {printf("�������Һ���:");scanf("%d",&(*t).data[i]);}
    else if(i%2==1) {printf("����������:");scanf("%d",&(*t).data[i]);}
    system("cls");
    }
}


int main()
{
    Tree t;
    for(;;)
    {
    Creat_Tree(&t);
    Print_Tree(t);
    Destroy_Tree(&t);
    }
}
