#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <windows.h>
#define N 10

typedef struct node
{
    char data;
    struct node *next;
    struct node *left;
    struct node *right;
}node,*pnode,**ppnode;


void creat_list(ppnode phead,ppnode ptail)//������������
{
    char i;
    int j;
    printf("���������Ԫ��:");
    while((i=getchar())!='\n'){
    pnode pnew=(pnode)calloc(1,sizeof(node));
    pnew->data=i;
    if((*phead)==NULL)
    {
        *phead=pnew;
        *ptail=pnew;
    }
    else {
        (*ptail)->next=pnew;
         *ptail=pnew;
    }
    }
}


void creat_tree(ppnode phead)//����������
{
    pnode tag=NULL,cur=NULL;
    if(*phead==NULL) {printf("����Ϊ��!\n");return;}
    else if(*phead!=NULL) {

        if(tag==NULL&&(*phead)->next) {tag=*phead;cur=tag->next;}
        while(cur)
        {
            if(tag->left==NULL) {tag->left=cur;}
            else if(tag->right==NULL) {tag->right=cur;tag=tag->next;}
            cur=cur->next;
        }
        }
}


void pre_order(pnode phead)
{
    if(phead!=NULL){
    printf("%c",phead->data);
    pre_order(phead->left);
    pre_order(phead->right);
    }
}


void mid_order(pnode phead)
{
    if(phead!=NULL){
    mid_order(phead->left);
    printf("%c",phead->data);
    mid_order(phead->right);
    }
}


void last_order(pnode phead)
{
    if(phead!=NULL){
    last_order(phead->left);
    last_order(phead->right);
    printf("%c",phead->data);
    }
}


int main()
{
    pnode phead=NULL,ptail=NULL;
    creat_list(&phead,&ptail);
    creat_tree(&phead);
    printf("ǰ�����:");pre_order(phead);printf("\n");
    printf("�������:");mid_order(phead);printf("\n");
    printf("�������:");last_order(phead);printf("\n");
}
