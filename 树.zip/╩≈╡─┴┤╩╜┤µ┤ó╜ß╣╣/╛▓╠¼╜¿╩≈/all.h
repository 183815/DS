#ifndef ALL_H_INCLUDED
#define ALL_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#define N 10

#endif // ALL_H_INCLUDED
typedef struct tree
{
    char ch;
    struct tree *left;
    struct tree *right;
}tree,*ptree,**pptree;
