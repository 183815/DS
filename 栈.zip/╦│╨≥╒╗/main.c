#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <windows.h>
#define N 10


typedef struct seqstack
{
    int a[N];
    int top;
}st,*sst;



void print_stack(st s)
{
    int i=s.top;
    while(i>=0)
    {
        printf("| %d |\n",s.a[i--]);
    }
    printf(" --- \n");
}


void Is_Empty_stack(st s)
{
    if(s.top==-1) printf("ջ��");
    else if(s.top==N-1) printf("ջ��");
    else printf("ջδ��");
    printf("\n");
}


void push_stack(sst s)
{
    int i;
    printf("\n������Ҫ��ջ��Ԫ��:");
    scanf("%d",&i);
    (*s).a[++(*s).top]=i;
}


void pop_stack(sst s)
{int j;
j=(*s).a[(*s).top--];
printf("��ջԪ��Ϊ%d \n",j);
system("pause");
}


int main()
{
    st s;
    memset(s.a,0,sizeof(s.a));
    s.top=-1;
    int i;
    for(;;)
    {
    print_stack(s);
    printf("\n��ѡ����ջ0���ǵ�ջ1:");
    scanf("%d",&i);
//    Is_Empty_stack(s);
    if(i==0) push_stack(&s);
    else if(i==1) pop_stack(&s);
    system("cls");
    }
}
