#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <windows.h>
#define N 10


typedef struct linkstack
{
    int data;
    struct linkstack *next;
}ls,*pls,**ppls;


void push_stack(ppls Lh)
{
    pls L1;
    int i;
    printf("��������ջԪ��:");
    scanf("%d",&i);
    L1=(pls)calloc(1,sizeof(ls));
    L1->data=i;
    if(*Lh==NULL) {*Lh=L1;}
    else {L1->next=*Lh;*Lh=L1;}
}


void print_stack(pls Lh)
{printf("ջ��->ջ��:");
      while(Lh)
  {
    printf("%d ",Lh->data);
    Lh=Lh->next;
  }
  printf("\n");
}


void pop_stack(ppls Lh)
{
    pls L1,t;
    char i;
    int j;
    printf("�Ƿ�ջ:");
    scanf("%s",&i);
    if(i=='y')
    {
    j=(*Lh)->data;
    printf("%d��ջ!\n",j);
    if(*Lh==NULL) {printf("ջ��");}
    else {L1=*Lh;*Lh=(*Lh)->next;free(L1);}}
}


int main()
{
  pls Lh=NULL;
  for(;;)
  {
  push_stack(&Lh);
  pop_stack(&Lh);
  print_stack(Lh);

  }
}
