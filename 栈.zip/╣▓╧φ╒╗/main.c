#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <windows.h>
#define N 10

typedef struct seqstack
{
    int a[N];
    int top,top1;
}st,*sst;



void print_stack1(st s)
{
    int i=0;
    while(i<=s.top)
    {
        printf("%d ",s.a[i++]);
    }
    printf("|");
}


void print_stack2(st s)
{
    int i=s.top1;
    while(i<N)
    {
        printf("%d ",s.a[i++]);
    }
}


void Is_Empty_stack(st s)
{
    if(s.top==-1) printf("\nջ��");
    else if(s.top==s.top1-1) printf("\nջ��,�޷����в���");
    else printf("\nջδ��");
    printf("\n");
}


void push_stack1(sst s)
{
    int i;
    printf("\n������Ҫ��ջ��Ԫ��:");
    scanf("%d",&i);
    (*s).a[++(*s).top]=i;
}


void push_stack2(sst s)
{
    int i;
    printf("\n������Ҫ��ջ��Ԫ��:");
    scanf("%d",&i);
    (*s).a[--(*s).top1]=i;
}


void pop_stack1(sst s)
{int j;
j=(*s).a[(*s).top--];
printf("��ջԪ��Ϊ%d \n",j);
system("pause");
}

void pop_stack2(sst s)
{int j;
j=(*s).a[(*s).top1++];
printf("��ջԪ��Ϊ%d \n",j);
system("pause");
}


int main()
{
    st s;
    memset(s.a,0,sizeof(s.a));
    s.top=-1;
    s.top1=N;
    int i;
    for(;;)
    {
    print_stack1(s);
    print_stack2(s);
    Is_Empty_stack(s);
    printf("\n��ѡ����ջ0���ǵ�ջ1:");
    scanf("%d",&i);
    if(i==0&&s.top1-1!=s.top)
    {
        printf("\n��ѡ����ջ1����ջ2:");
        scanf("%d",&i);
        if(i==1) push_stack1(&s);
        else if(i==2) push_stack2(&s);
    }
    else if(i==1)
    {
        printf("\n��ѡ��ջ1���ǵ�ջ2:");
        scanf("%d",&i);
        if(i==1) pop_stack1(&s);
        else if(i==2) pop_stack2(&s);
    }
    system("cls");
    }
}
